package org.xokyopo.filesharing.Core.Repository.Adapter;

import org.xokyopo.filesharing.Core.Template.FilePathID;

import java.io.File;

public interface RepositoryAInput {
    FilePathID save(File file);
    File get(FilePathID filePath);
    boolean delete(FilePathID filePath);
}
