package org.xokyopo.filesharing.Core.DataBase.Adapter;

import org.xokyopo.filesharing.Core.Template.FilePathID;
import org.xokyopo.filesharing.Core.Template.ID;

public interface DataBaseAInput {
    ID save(FilePathID pathName);
    FilePathID get(ID id);
    boolean update(ID id);
    boolean delete(ID id);
}
