<!DOCTYPE html>
<?php
	$host="https://xokyopo.000webhostapp.com/";
?>

<html>
<head>
	<meta charset="utf-8">
	<title>Личный сайт студента GeekBrains</title>
	<link rel="stylesheet" href="<?php echo $host."style.css" ?>"> 
</head>
<body>

<div class="header">
	<a href="<?php echo $host."index.php"?>">Главная</a>
	<a href="<?php echo $host."education/programming_basics/HW_n_4/puzzle.php"?>">Загадки</a>
	<a href="<?php echo $host."education/programming_basics/HW_n_4/guess.php"?>">Угадайка</a>
	<a href="<?php echo $host."education/programming_basics/HW_n_4/passGenerator.php"?>">Генератор паролей</a>
	<a href="<?php echo $host."tamplate.php"?>">Шаблон</a>
</div>
