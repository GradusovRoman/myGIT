<div class="footer">
	Copyright &copy; <?php echo date("Y"); ?>
<div>

</body>
</html>