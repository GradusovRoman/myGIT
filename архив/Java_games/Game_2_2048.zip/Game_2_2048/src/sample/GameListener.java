package sample;


import javafx.event.Event;
import javafx.event.EventHandler;

public class GameListener implements EventHandler {
    @Override
    public void handle(Event event) {

    }
}
