package org.xokyopo.filesharing.Features;

import org.xokyopo.filesharing.Core.DataBase.Adapter.DataBaseAdapter;
import org.xokyopo.filesharing.Core.Repository.Adapter.RepositoryAdapter;
import org.xokyopo.filesharing.Core.Template.ID;

public class UpdateCounter {
    private final DataBaseAdapter dataBaseAdapter;
    private final RepositoryAdapter repositoryAdapter;

    public UpdateCounter(DataBaseAdapter dataBaseA, RepositoryAdapter repositoryA) {
        this.dataBaseAdapter = dataBaseA;
        this.repositoryAdapter = repositoryA;
    }

    public boolean update(ID filePath) {
        //обновляем время хранения файла
        boolean result = this.dataBaseAdapter.update(filePath);
        return result;
    }
}
