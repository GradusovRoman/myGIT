package org.xokyopo.filesharing;

import org.xokyopo.filesharing.Core.Template.FilePathID;
import org.xokyopo.filesharing.Core.Template.ID;
import org.xokyopo.filesharing.Features.DepenceInjector.Loader;

import java.io.File;

public class Main {
    public static void main(String[] args) {
        //TODO тесты прошли успешно :) осталось написать ГУИ
        Loader loader = new Loader();

        File file = new File("D:\\GIT\\Java\\Java_plus\\filesharing\\filesharing.iml");
//        file = new File("D:/temp/filesharing.sqlite3");
//        System.out.println(file.exists());
//        ID s = loader.getSave().save(file);
//        System.out.println(s.getId());

        loader.getDataBase().disconnection();
    }
}
