<?php
	$root=$_SERVER["DOCUMENT_ROOT"];
	include $root."/header.php";
?>

<div class="content">



</div>

<?php
	include $root."/footer.php";
?>